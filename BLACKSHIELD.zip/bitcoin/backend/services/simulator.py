"""Safe, local-only synthetic exchange activity for demonstration and tests."""
import json
import secrets
from datetime import datetime

from ..models import Alert, SecurityEvent, Transaction
from .risk_engine import assess


def _event(db, event_type, severity, source, description, risk):
    db.add(SecurityEvent(event_type=event_type, severity=severity, source=source,
                         description=description, risk_score=risk))


def simulate(db, scenario: str) -> dict:
    """Persist a controlled scenario. It never connects to wallets or a network."""
    scenarios = {"normal", "suspicious_transaction", "access_anomaly", "potential_breach"}
    if scenario not in scenarios:
        raise ValueError(f"scenario must be one of: {', '.join(sorted(scenarios))}")
    incident = scenario == "potential_breach"
    access = scenario in {"access_anomaly", "potential_breach"}
    amount = 8.42 if incident else (3.6 if scenario == "suspicious_transaction" else 0.12)
    kind = "withdrawal" if scenario != "normal" else "deposit"
    anomaly = 0.94 if incident else (0.72 if scenario != "normal" else 0.08)
    analysis = assess(amount, 0.003 if kind == "withdrawal" else 0.0001, kind, anomaly)
    tx = Transaction(
        transaction_id=f"sim-{datetime.utcnow():%Y%m%d%H%M%S}-{secrets.token_hex(3)}",
        amount=amount, fee=0.003 if kind == "withdrawal" else 0.0001,
        wallet="bc1qsimulatedexchangewallet", transaction_type=kind,
        anomaly_score=analysis["anomaly_score"], risk_score=analysis["risk_score"],
        severity=analysis["severity"], status=analysis["severity"] if analysis["risk_score"] >= 30 else "NORMAL",
        detection_reasons=json.dumps(analysis["signals"]),
    )
    db.add(tx)
    if access:
        _event(db, "FAILED_LOGIN", "HIGH", "Authentication Monitor",
               "Simulated repeated failed authentication pattern.", 76)
        _event(db, "API_REQUEST", "HIGH", "Exchange API",
               "Simulated API request-rate deviation.", 71)
    if incident:
        _event(db, "NEW_WITHDRAWAL_ADDRESS", "HIGH", "Wallet Service",
               "Simulated new withdrawal destination observed.", 85)
        _event(db, "WITHDRAWAL", "CRITICAL", "Withdrawal Service",
               "Simulated large withdrawal request correlated with access signals.", 94)
        alert = Alert(title="Potential Exchange Breach (Simulated)", severity="CRITICAL", risk_score=94,
                      source="Correlation Engine", affected_component="Withdrawal Service",
                      description="Synthetic correlated activity requires investigation; it does not establish a real breach.",
                      detection_signals=json.dumps(["Repeated failed authentication", "New withdrawal address", "API request deviation", "Large withdrawal", "Transaction frequency spike"]))
        db.add(alert)
    elif analysis["risk_score"] >= 30:
        db.add(Alert(title="Simulated high-risk activity", severity=analysis["severity"], risk_score=analysis["risk_score"],
                     source="Demo Simulator", affected_component="Transaction Monitor",
                     description="Synthetic activity requiring investigation.", detection_signals=json.dumps(analysis["signals"])))
    db.commit()
    db.refresh(tx)
    return {"scenario": scenario, "simulated": True, "transaction_id": tx.transaction_id,
            "risk_score": analysis["risk_score"], "severity": analysis["severity"]}
