"""Local risk, alert, upload, and dashboard services."""
