import csv, io, json
from fastapi import HTTPException
def parse_upload(filename, content):
    suffix=filename.rsplit('.',1)[-1].lower() if '.' in filename else ''
    text=content.decode('utf-8', errors='replace')
    if suffix=='json':
        try: data=json.loads(text)
        except json.JSONDecodeError: raise HTTPException(400,'Invalid JSON upload')
        rows=data if isinstance(data,list) else data.get('data',[])
        if not isinstance(rows,list): raise HTTPException(400,'JSON must contain an array of records')
        columns=list(rows[0].keys()) if rows and isinstance(rows[0],dict) else []
    elif suffix in {'csv','log'}:
        if suffix=='log':
            rows=[{'message':line} for line in text.splitlines() if line.strip()]; columns=['message']
        else:
            rows=list(csv.DictReader(io.StringIO(text))); columns=list(rows[0].keys()) if rows else []
    else: raise HTTPException(400,'Unsupported file type')
    return columns, rows[:10], len(rows)
