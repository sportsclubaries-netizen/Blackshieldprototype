"""Transparent prototype scoring. It indicates statistical/rule-based concern, not criminality."""
def severity(score): return 'CRITICAL' if score>=80 else 'HIGH' if score>=60 else 'MEDIUM' if score>=30 else 'LOW'
def assess(amount, fee=0, transaction_type='transfer', anomaly_score=None):
    anomaly_score = anomaly_score if anomaly_score is not None else min(0.98, amount/12)
    signals=[]; score=round(anomaly_score*45)
    if amount>=5: score+=25; signals.append('Transaction amount significantly exceeds local baseline')
    if transaction_type.lower()=='withdrawal': score+=15; signals.append('Withdrawal behavior requires review')
    if fee>0 and fee/max(amount, .001)>.01: score+=8; signals.append('Transaction fee deviation')
    if anomaly_score>=.7: signals.append('Statistical anomaly signal')
    score=min(100,score)
    return {'risk_score':score,'severity':severity(score),'signals':signals or ['No elevated rule-based signal detected'],'anomaly_score':round(anomaly_score,2),'is_anomaly':anomaly_score>=.55}
