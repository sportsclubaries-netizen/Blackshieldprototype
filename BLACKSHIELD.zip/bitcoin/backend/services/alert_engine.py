import json
from ..models import Alert
def create_alert_if_needed(db, analysis, transaction):
    if analysis['risk_score'] < 30: return None
    alert=Alert(title='Potential withdrawal anomaly' if transaction.transaction_type=='withdrawal' else 'Elevated transaction activity',severity=analysis['severity'],risk_score=analysis['risk_score'],source='Transaction Monitor',affected_component='Withdrawal Service' if transaction.transaction_type=='withdrawal' else 'Transaction Monitor',description='Local prototype signal requiring analyst review; this does not establish malicious activity.',detection_signals=json.dumps(analysis['signals']))
    db.add(alert); return alert
