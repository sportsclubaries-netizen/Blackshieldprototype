"""Offline statistical anomaly detection components."""
