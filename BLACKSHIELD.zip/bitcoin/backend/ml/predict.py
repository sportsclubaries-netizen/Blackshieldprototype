"""Offline Isolation Forest inference with a transparent fallback.

The fallback is deliberately labelled by callers as prototype scoring.  It is
not a claim that a transaction is malicious when a saved model is unavailable.
"""
from pathlib import Path

import joblib

from ..services.risk_engine import assess
from .feature_engineering import transaction_features


MODEL_PATH = Path(__file__).with_name("model.pkl")


def model_available() -> bool:
    return MODEL_PATH.is_file()


def analyze_transaction(transaction):
    """Return a 0-1 statistical anomaly score and its prototype risk analysis."""
    anomaly_score = None
    if model_available():
        model = joblib.load(MODEL_PATH)
        # IsolationForest scores become lower for outliers.  Map the local
        # decision score to a bounded, easy-to-consume anomaly score.
        decision = float(model.decision_function([transaction_features(transaction)])[0])
        anomaly_score = max(0.0, min(1.0, 0.5 - decision * 5))
    return assess(
        transaction.amount,
        transaction.fee,
        transaction.transaction_type,
        anomaly_score=anomaly_score,
    )
