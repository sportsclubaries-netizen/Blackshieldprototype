from pathlib import Path
import joblib
from sklearn.ensemble import IsolationForest
from .feature_engineering import transaction_features
def train_model(transactions, output_path=None):
    if len(transactions)<2: return None
    model=IsolationForest(contamination='auto',random_state=42).fit([transaction_features(t) for t in transactions])
    if output_path: joblib.dump(model,Path(output_path))
    return model
