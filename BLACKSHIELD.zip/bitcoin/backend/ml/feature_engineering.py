def transaction_features(transaction): return [float(transaction.amount),float(transaction.fee),1 if transaction.transaction_type=='withdrawal' else 0]
