# BLACKSHIELD backend

Local, offline-first FastAPI prototype for the BLACKSHIELD exchange-security console. It uses SQLite and seeded **demo data**; risk signals flag statistical or rule-based anomalies and do not prove malicious activity or guarantee breach detection.

## Run locally

From the project root on Windows or Linux, create a **new** virtual
environment. Do not reuse a `backend/.venv` directory copied from another
computer: virtual environments contain machine-specific Python paths.

```bash
py -3.12 -m venv backend/.venv
# Windows PowerShell: .\backend\.venv\Scripts\Activate.ps1
# Linux: source backend/.venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r backend/requirements.txt
python -m uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

If `py` is not recognized, install Python 3.12 from python.org and select
"Add Python to PATH" during installation. When using VS Code Live Server,
the default `http://localhost:5500` and `http://127.0.0.1:5500` origins are
already allowed. For a different frontend origin, set
`BLACKSHIELD_CORS_ORIGINS` before starting the server.

On Windows, after installing Python, you can instead double-click
`start-backend.cmd` in the project root. Keep its command window open while
using the frontend; it hosts the local API.

Open `http://127.0.0.1:8000/` for the dashboard or `http://127.0.0.1:8000/docs` for the API reference. The backend serves the dashboard itself, so no separate frontend server is needed. Use `owner` / `demo123` with `POST /api/auth/login`, then pass the returned token as `Authorization: Bearer <token>`.

## Architecture

`main.py` exposes the API; SQLAlchemy models are in `models/`; the transparent prototype risk and alert logic is in `services/`; the Isolation Forest trainer is in `ml/`. Uploads are validated and stored only under `data/uploads/`; no uploaded file is executed or sent externally.

## Frontend

Allow the frontend development origin through `BLACKSHIELD_CORS_ORIGINS` (see `.env.example`). Current endpoints are under `/api/auth`, `/api/dashboard`, `/api/transactions`, `/api/uploads`, `/api/threats`, `/api/alerts`, `/api/wallets`, `/api/system`, `/api/ml`, and `/api/settings`.

## Train the local model

Log in through `/docs`, authorize with the returned bearer token, then call `POST /api/ml/train`. The resulting `ml/model.pkl` stays local. Until it exists, the API explicitly reports `MODEL_NOT_TRAINED` and uses configurable, transparent prototype rules rather than fabricated model performance.

## Limitations and security notes

This prototype does not prove criminal activity, detect every breach, or replace a security operations process. It performs no cloud calls and never executes uploaded files. Production use requires a managed secret store, real identity/session lifecycle, rate limiting, audit retention, TLS, and a reviewed deployment configuration.

## Limitations

The authentication token store is in memory, SQLite is for prototyping, and model outputs are demo/statistical signals. Production use requires persistent sessions, production database configuration, audit controls, real agent data, and a validated detection program.
