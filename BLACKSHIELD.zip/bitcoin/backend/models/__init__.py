from datetime import datetime
from sqlalchemy import String, Integer, Float, DateTime, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column
from ..database import Base

class User(Base):
    __tablename__='users'; id: Mapped[int]=mapped_column(primary_key=True); username: Mapped[str]=mapped_column(String(64),unique=True,index=True); password_hash: Mapped[str]=mapped_column(String(256)); role: Mapped[str]=mapped_column(String(32),default='owner')
class Transaction(Base):
    __tablename__='transactions'; id: Mapped[int]=mapped_column(primary_key=True); transaction_id: Mapped[str]=mapped_column(String(128),unique=True,index=True); timestamp: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow); amount: Mapped[float]=mapped_column(Float); fee: Mapped[float]=mapped_column(Float,default=0); wallet: Mapped[str]=mapped_column(String(160),index=True); transaction_type: Mapped[str]=mapped_column(String(32)); anomaly_score: Mapped[float]=mapped_column(Float,default=0); risk_score: Mapped[int]=mapped_column(Integer,default=0); severity: Mapped[str]=mapped_column(String(16),default='LOW'); status: Mapped[str]=mapped_column(String(32),default='NORMAL'); detection_reasons: Mapped[str]=mapped_column(Text,default='[]')
class Alert(Base):
    __tablename__='alerts'; id: Mapped[int]=mapped_column(primary_key=True); title: Mapped[str]=mapped_column(String(180)); severity: Mapped[str]=mapped_column(String(16)); risk_score: Mapped[int]=mapped_column(Integer); timestamp: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow); source: Mapped[str]=mapped_column(String(100)); affected_component: Mapped[str]=mapped_column(String(100)); description: Mapped[str]=mapped_column(Text); detection_signals: Mapped[str]=mapped_column(Text,default='[]'); status: Mapped[str]=mapped_column(String(32),default='NEW')
class Wallet(Base):
    __tablename__='wallets'; id: Mapped[int]=mapped_column(primary_key=True); address: Mapped[str]=mapped_column(String(160),unique=True,index=True); transaction_count: Mapped[int]=mapped_column(Integer,default=0); last_activity: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow); anomalies: Mapped[int]=mapped_column(Integer,default=0); risk_score: Mapped[int]=mapped_column(Integer,default=0); status: Mapped[str]=mapped_column(String(32),default='NORMAL')
class SecurityEvent(Base):
    __tablename__='security_events'; id: Mapped[int]=mapped_column(primary_key=True); timestamp: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow); event_type: Mapped[str]=mapped_column(String(40)); severity: Mapped[str]=mapped_column(String(16)); source: Mapped[str]=mapped_column(String(100)); description: Mapped[str]=mapped_column(Text); risk_score: Mapped[int]=mapped_column(Integer,default=0)
class AnalysisResult(Base):
    __tablename__='analysis_results'; id: Mapped[int]=mapped_column(primary_key=True); created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow); records_analyzed: Mapped[int]=mapped_column(Integer,default=0); anomalies: Mapped[int]=mapped_column(Integer,default=0)
class SystemStatus(Base):
    __tablename__='system_status'; id: Mapped[int]=mapped_column(primary_key=True); monitoring_enabled: Mapped[bool]=mapped_column(Boolean,default=True); analysis_interval: Mapped[int]=mapped_column(Integer,default=5); risk_medium_threshold: Mapped[int]=mapped_column(Integer,default=30); risk_high_threshold: Mapped[int]=mapped_column(Integer,default=60); risk_critical_threshold: Mapped[int]=mapped_column(Integer,default=80); alert_notifications: Mapped[bool]=mapped_column(Boolean,default=True); demo_mode: Mapped[bool]=mapped_column(Boolean,default=True)
