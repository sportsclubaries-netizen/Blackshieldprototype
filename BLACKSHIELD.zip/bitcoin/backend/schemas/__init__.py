"""Pydantic request and response contracts are defined alongside the prototype API endpoints."""
