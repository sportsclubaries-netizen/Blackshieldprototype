"""Route namespace reserved for future domain routers; prototype routes are registered in main.py."""
