import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATABASE_URL = os.getenv("BLACKSHIELD_DATABASE_URL", f"sqlite:///{BASE_DIR / 'blackshield.db'}")
# Keep the default local development servers usable without requiring a
# separate environment variable.  In particular, VS Code Live Server uses
# port 5500; previously browser requests from it were blocked by CORS.
CORS_ORIGINS = os.getenv(
    "BLACKSHIELD_CORS_ORIGINS",
    "http://localhost:4173,http://localhost:5173,"
    "http://localhost:5500,http://127.0.0.1:5500",
).split(",")
UPLOAD_DIR = BASE_DIR / "data" / "uploads"
UPLOAD_MAX_BYTES = int(os.getenv("BLACKSHIELD_UPLOAD_MAX_MB", "15")) * 1024 * 1024
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
