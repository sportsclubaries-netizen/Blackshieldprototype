import hashlib, hmac, json, logging, secrets
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, Depends, File, HTTPException, UploadFile, Header, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, desc
from sqlalchemy.orm import Session
from .config import CORS_ORIGINS, UPLOAD_DIR, UPLOAD_MAX_BYTES
from .database import Base, engine, get_db, SessionLocal
from .models import User, Transaction, Alert, Wallet, SecurityEvent, AnalysisResult, SystemStatus
from .services.risk_engine import assess
from .services.alert_engine import create_alert_if_needed
from .services.file_processor import parse_upload
from .ml.train import train_model
from .ml.predict import analyze_transaction, model_available
from .services.simulator import simulate

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s %(message)s')
log=logging.getLogger('blackshield')
app=FastAPI(title='BLACKSHIELD Local Security API',version='0.1.0',description='Offline-first prototype API. Demo signals indicate potential anomalous activity only.')
app.add_middleware(CORSMiddleware,allow_origins=CORS_ORIGINS,allow_credentials=True,allow_methods=['GET','POST','PATCH'],allow_headers=['Authorization','Content-Type'])
TOKENS={}
def password_hash(password, salt=None):
    salt=salt or secrets.token_bytes(16); digest=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,210000); return salt.hex()+'$'+digest.hex()
def password_ok(password, encoded):
    salt, digest=encoded.split('$',1); candidate=password_hash(password,bytes.fromhex(salt)).split('$',1)[1]; return hmac.compare_digest(candidate,digest)
def demo_seed():
    db=SessionLocal()
    try:
        if not db.query(User).filter_by(username='owner').first(): db.add(User(username='owner',password_hash=password_hash('demo123'),role='owner'))
        if not db.query(SystemStatus).first(): db.add(SystemStatus())
        if not db.query(Transaction).first():
            seed=[('8f3a91bc',8.42,.003,'bc1q91x8a3','withdrawal',.94),('c24b71d8',.482,.0002,'bc1q9w2k7a','transfer',.81),('77d921ae',.051,.0001,'bc1q6pxq2c','withdrawal',.57),('f05abc11',1.29,.0003,'bc1q2r3s9d','transfer',.22)]
            for tid,amount,fee,wallet,kind,anomaly in seed:
                a=assess(amount,fee,kind,anomaly); t=Transaction(transaction_id=tid,amount=amount,fee=fee,wallet=wallet,transaction_type=kind,anomaly_score=a['anomaly_score'],risk_score=a['risk_score'],severity=a['severity'],status='NORMAL' if a['risk_score']<30 else a['severity'],detection_reasons=json.dumps(a['signals'])); db.add(t)
            db.flush()
            for address,count,anomalies,risk,status in [('bc1q91x8a3',3281,4,94,'REQUIRES_INVESTIGATION'),('bc1q9w2k7a',2908,2,81,'HIGH_RISK'),('bc1q6pxq2c',1743,1,57,'MONITORING'),('bc1q2r3s9d',4551,0,24,'NORMAL')]: db.add(Wallet(address=address,transaction_count=count,anomalies=anomalies,risk_score=risk,status=status))
            db.add_all([Alert(title='Potential Exchange Breach',severity='CRITICAL',risk_score=94,source='Withdrawal Monitor',affected_component='Withdrawal Service',description='Correlated demo signals require owner investigation.',detection_signals=json.dumps(['Abnormal transaction volume','New withdrawal address','Unusual API activity'])),Alert(title='Abnormal Transaction Burst',severity='HIGH',risk_score=81,source='Transaction Monitor',affected_component='Transaction Monitor',description='Elevated frequency in local demo data.',detection_signals=json.dumps(['Transaction frequency deviation']),status='INVESTIGATING')])
            for typ,sev,source,description,risk in [('WITHDRAWAL','HIGH','Withdrawal Service','Withdrawal request received',81),('SECURITY_EVENT','HIGH','Wallet Service','New withdrawal address observed',76),('AUTHENTICATION','MEDIUM','Exchange Server','Authentication event deviates from baseline',57),('API_REQUEST','HIGH','Exchange API','API request spike observed',71),('TRANSACTION','LOW','Transaction Monitor','Transaction validated',24)]: db.add(SecurityEvent(event_type=typ,severity=sev,source=source,description=description,risk_score=risk))
        db.commit()
    finally: db.close()
@app.on_event('startup')
def startup(): Base.metadata.create_all(bind=engine); demo_seed(); log.info('BLACKSHIELD local API started')
@app.on_event('shutdown')
def shutdown(): log.info('BLACKSHIELD local API stopped')
def user_from_token(authorization: Optional[str]=Header(None), db: Session=Depends(get_db)):
    if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'Authentication required')
    username=TOKENS.get(authorization[7:]); user=db.query(User).filter_by(username=username).first() if username else None
    if not user: raise HTTPException(401,'Invalid or expired session')
    return user
class LoginRequest(BaseModel): username:str=Field(min_length=1,max_length=64); password:str=Field(min_length=1,max_length=256)
class TransactionCreate(BaseModel): transaction_id:str=Field(min_length=4,max_length=128); amount:float=Field(gt=0); fee:float=Field(ge=0); wallet:str=Field(min_length=3,max_length=160); transaction_type:str=Field(default='transfer',pattern='^(transfer|withdrawal|deposit)$')
class AlertUpdate(BaseModel): status:str=Field(pattern='^(NEW|ACKNOWLEDGED|INVESTIGATING|RESOLVED)$')
class SettingsUpdate(BaseModel): monitoring_enabled:Optional[bool]=None; analysis_interval:Optional[int]=Field(default=None,ge=1,le=3600); risk_medium_threshold:Optional[int]=Field(default=None,ge=0,le=100); risk_high_threshold:Optional[int]=Field(default=None,ge=0,le=100); risk_critical_threshold:Optional[int]=Field(default=None,ge=0,le=100); alert_notifications:Optional[bool]=None; demo_mode:Optional[bool]=None
def tx_out(t): return {'transaction_id':t.transaction_id,'timestamp':t.timestamp,'amount':t.amount,'fee':t.fee,'wallet':t.wallet,'input_wallets':[t.wallet],'output_wallets':[t.wallet],'transaction_type':t.transaction_type,'anomaly_score':t.anomaly_score,'risk_score':t.risk_score,'severity':t.severity,'status':t.status,'detection_reasons':json.loads(t.detection_reasons or '[]')}
def alert_out(a): return {'id':a.id,'title':a.title,'severity':a.severity,'risk_score':a.risk_score,'timestamp':a.timestamp,'source':a.source,'affected_component':a.affected_component,'description':a.description,'detection_signals':json.loads(a.detection_signals or '[]'),'status':a.status}
@app.get('/api/health',tags=['system'])
def health(): return {'status':'ONLINE','mode':'OFFLINE','demo_data':True}
@app.post('/api/auth/login',tags=['auth'])
def login(data:LoginRequest, db:Session=Depends(get_db)):
    user=db.query(User).filter_by(username=data.username).first()
    if not user or not password_ok(data.password,user.password_hash): log.warning('failed login for username=%s',data.username); raise HTTPException(401,'Invalid credentials')
    token=secrets.token_urlsafe(32); TOKENS[token]=user.username; log.info('local login username=%s',user.username); return {'access_token':token,'token_type':'bearer','user':{'username':user.username,'role':user.role}}
@app.get('/api/auth/me',tags=['auth'])
def me(user:User=Depends(user_from_token)): return {'username':user.username,'role':user.role}
@app.get('/api/dashboard/overview',tags=['dashboard'])
def dashboard(db:Session=Depends(get_db), user:User=Depends(user_from_token)):
    total=db.query(Transaction).count(); anomalous=db.query(Transaction).filter(Transaction.risk_score>=30).count(); active=db.query(Alert).filter(Alert.status.in_(['NEW','INVESTIGATING'])).count(); average=db.query(func.avg(Transaction.risk_score)).scalar() or 0
    return {'protection_status':'PROTECTED','risk_score':round(average),'transactions_monitored':total or 0,'anomalies_detected':anomalous,'active_alerts':active,'system_uptime':'18h 42m','demo_data':True}
@app.get('/api/dashboard/risk-activity',tags=['dashboard'])
def risk_activity(db:Session=Depends(get_db), user:User=Depends(user_from_token)):
    base=datetime.utcnow()-timedelta(hours=23); scores=[15,19,28,22,31,38,27,42,35,51,29,44,57,38,62,74,45,59,48,70,55,41,63,52]; return [{'timestamp':(base+timedelta(hours=i)).isoformat(),'risk_score':s} for i,s in enumerate(scores)]
@app.get('/api/transactions',tags=['transactions'])
def transactions(page:int=Query(1,ge=1),page_size:int=Query(25,ge=1,le=100),risk:Optional[str]=None,status:Optional[str]=None,search:Optional[str]=None,db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    q=db.query(Transaction)
    if risk: q=q.filter(Transaction.severity==risk.upper())
    if status: q=q.filter(Transaction.status==status.upper())
    if search: q=q.filter(or_(Transaction.transaction_id.contains(search),Transaction.wallet.contains(search)))
    total=q.count(); return {'items':[tx_out(t) for t in q.order_by(desc(Transaction.timestamp)).offset((page-1)*page_size).limit(page_size)],'page':page,'page_size':page_size,'total':total}
@app.get('/api/transactions/{transaction_id}',tags=['transactions'])
def transaction_detail(transaction_id:str,db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    t=db.query(Transaction).filter_by(transaction_id=transaction_id).first()
    if not t: raise HTTPException(404,'Transaction not found')
    return tx_out(t)
@app.post('/api/transactions',status_code=201,tags=['transactions'])
def create_transaction(data:TransactionCreate,db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    if db.query(Transaction).filter_by(transaction_id=data.transaction_id).first(): raise HTTPException(400,'Transaction ID already exists')
    # Build a light object for model feature extraction before persisting it.
    candidate=Transaction(**data.model_dump())
    analysis=analyze_transaction(candidate)
    t=Transaction(**data.model_dump(),anomaly_score=analysis['anomaly_score'],risk_score=analysis['risk_score'],severity=analysis['severity'],status=analysis['severity'] if analysis['risk_score']>=30 else 'NORMAL',detection_reasons=json.dumps(analysis['signals'])); db.add(t); db.flush(); alert=create_alert_if_needed(db,analysis,t); db.commit(); db.refresh(t); log.info('transaction analyzed id=%s risk=%s',t.transaction_id,t.risk_score); return {'transaction':tx_out(t),'analysis':analysis,'alert':alert_out(alert) if alert else None}
async def local_upload(file:UploadFile, allowed:set, db:Session):
    suffix=Path(file.filename or '').suffix.lower().lstrip('.');
    if suffix not in allowed: raise HTTPException(400,f'Allowed types: {", ".join(sorted(allowed))}')
    content=await file.read()
    if not content: raise HTTPException(400,'Uploaded file is empty')
    if len(content)>UPLOAD_MAX_BYTES: raise HTTPException(400,'Upload exceeds configured size limit')
    columns,preview,records=parse_upload(file.filename or 'upload',content); safe_name=f'{datetime.utcnow():%Y%m%d%H%M%S}_{secrets.token_hex(4)}.{suffix}'; (UPLOAD_DIR/safe_name).write_bytes(content); log.info('local upload filename=%s records=%s',safe_name,records); return {'filename':file.filename,'records':records,'status':'VALIDATED','columns':columns,'missing_values':sum(1 for row in preview for v in row.values() if v in (None,'')),'preview':preview,'demo_data':False}
@app.post('/api/uploads/transactions',tags=['uploads'])
async def upload_transactions(file:UploadFile=File(...),db:Session=Depends(get_db),user:User=Depends(user_from_token)): return await local_upload(file,{'csv','json'},db)
@app.post('/api/uploads/security-logs',tags=['uploads'])
async def upload_logs(file:UploadFile=File(...),db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    result=await local_upload(file,{'csv','json','log'},db); result['records_loaded']=result.pop('records'); result['validation_status']=result.pop('status'); result['event_types']=['AUTHENTICATION','WITHDRAWAL','API_REQUEST']; return result
@app.get('/api/alerts',tags=['alerts'])
def alerts(severity:Optional[str]=None,status:Optional[str]=None,date:Optional[str]=None,db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    q=db.query(Alert)
    if severity:q=q.filter(Alert.severity==severity.upper())
    if status:q=q.filter(Alert.status==status.upper())
    if date:
        try: q=q.filter(func.date(Alert.timestamp)==date)
        except ValueError: raise HTTPException(422,'date must use YYYY-MM-DD')
    return [alert_out(a) for a in q.order_by(desc(Alert.timestamp)).all()]
@app.get('/api/alerts/{alert_id}',tags=['alerts'])
def get_alert(alert_id:int,db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    a=db.get(Alert,alert_id)
    if not a: raise HTTPException(404,'Alert not found')
    return alert_out(a)
@app.patch('/api/alerts/{alert_id}',tags=['alerts'])
def update_alert(alert_id:int,data:AlertUpdate,db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    a=db.get(Alert,alert_id)
    if not a: raise HTTPException(404,'Alert not found')
    a.status=data.status; db.commit(); db.refresh(a); return alert_out(a)
@app.post('/api/alerts/{alert_id}/acknowledge',tags=['alerts'])
def acknowledge(alert_id:int,db:Session=Depends(get_db),user:User=Depends(user_from_token)): return update_alert(alert_id,AlertUpdate(status='ACKNOWLEDGED'),db,user)
@app.post('/api/alerts/{alert_id}/resolve',tags=['alerts'])
def resolve(alert_id:int,db:Session=Depends(get_db),user:User=Depends(user_from_token)): return update_alert(alert_id,AlertUpdate(status='RESOLVED'),db,user)
@app.get('/api/wallets',tags=['wallets'])
def wallets(search:Optional[str]=None,risk:Optional[str]=None,db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    q=db.query(Wallet)
    if search:q=q.filter(Wallet.address.contains(search))
    if risk:q=q.filter(Wallet.status==risk.upper())
    return [{'wallet':w.address,'transaction_count':w.transaction_count,'last_activity':w.last_activity,'anomalies':w.anomalies,'risk_score':w.risk_score,'status':w.status} for w in q.all()]
@app.get('/api/wallets/{wallet_address}',tags=['wallets'])
def wallet(wallet_address:str,db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    w=db.query(Wallet).filter_by(address=wallet_address).first()
    if not w:raise HTTPException(404,'Wallet not found')
    recent=[tx_out(t) for t in db.query(Transaction).filter_by(wallet=w.address).order_by(desc(Transaction.timestamp)).limit(10)]
    return {'wallet':w.address,'transaction_count':w.transaction_count,'last_activity':w.last_activity,'anomalies':w.anomalies,'risk_score':w.risk_score,'status':w.status,'recent_transactions':recent,'risk_history':[w.risk_score,max(0,w.risk_score-8),max(0,w.risk_score-16)]}
@app.get('/api/system/events',tags=['system'])
def system_events(page:int=Query(1,ge=1),page_size:int=Query(25,ge=1,le=100),db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    q=db.query(SecurityEvent).order_by(desc(SecurityEvent.timestamp)); total=q.count(); return {'items':[{'timestamp':e.timestamp,'event_type':e.event_type,'severity':e.severity,'source':e.source,'description':e.description,'risk_score':e.risk_score} for e in q.offset((page-1)*page_size).limit(page_size)],'page':page,'page_size':page_size,'total':total}
@app.get('/api/system/status',tags=['system'])
def system_status(user:User=Depends(user_from_token)): return {'linux_agent':'ONLINE','database':'ONLINE','ml_engine':'ACTIVE','risk_engine':'ONLINE','transaction_monitor':'ONLINE','alert_engine':'ONLINE','mode':'OFFLINE','demo_data':True}
@app.get('/api/threats',tags=['threats'])
def threats(db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    return {'transaction_anomalies':db.query(Transaction).filter(Transaction.risk_score>=30).count(),'withdrawal_anomalies':db.query(Transaction).filter(Transaction.transaction_type=='withdrawal',Transaction.risk_score>=30).count(),'authentication_anomalies':db.query(SecurityEvent).filter_by(event_type='AUTHENTICATION').count(),'api_anomalies':db.query(SecurityEvent).filter_by(event_type='API_REQUEST').count(),'demo_data':True}
@app.get('/api/threats/recent',tags=['threats'])
def recent_threats(db:Session=Depends(get_db),user:User=Depends(user_from_token)): return [alert_out(a) for a in db.query(Alert).filter(Alert.risk_score>=30).order_by(desc(Alert.timestamp)).limit(10)]
@app.get('/api/ml/status',tags=['ml'])
def ml_status(db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    count=db.query(Transaction).count(); anomalies=db.query(Transaction).filter(Transaction.risk_score>=30).count(); trained=model_available(); return {'model':'Isolation Forest','status':'ACTIVE' if trained else 'MODEL_NOT_TRAINED','mode':'OFFLINE','model_version':'1.0','training_records':count if trained else 0,'events_analyzed':count,'anomalies':anomalies,'demo_fallback':not trained,'note':'Without a trained model, transactions use transparent prototype scoring.' if not trained else 'Offline model detects statistical abnormality, not criminal activity.'}
@app.post('/api/ml/train',tags=['ml'])
def ml_train(db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    rows=db.query(Transaction).all(); model=train_model(rows,Path(__file__).parent/'ml'/'model.pkl')
    if not model: raise HTTPException(400,'MODEL_NOT_TRAINED: at least two transactions are required')
    return {'status':'trained','records_used':len(rows),'model_version':'1.0','note':'Prototype model detects statistical abnormality, not criminal activity.'}
@app.post('/api/demo/simulate/{scenario}', tags=['demo'])
def demo_simulate(scenario:str, db:Session=Depends(get_db), user:User=Depends(user_from_token)):
    """Generate safe local demonstration data; no real exchange action is performed."""
    try: return simulate(db, scenario)
    except ValueError as error: raise HTTPException(422, str(error))
@app.get('/api/settings',tags=['settings'])
def settings(db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    s=db.query(SystemStatus).first(); return {k:getattr(s,k) for k in SettingsUpdate.model_fields}
@app.patch('/api/settings',tags=['settings'])
def update_settings(data:SettingsUpdate,db:Session=Depends(get_db),user:User=Depends(user_from_token)):
    s=db.query(SystemStatus).first(); values=data.model_dump(exclude_none=True)
    for k,v in values.items():setattr(s,k,v)
    if not (s.risk_medium_threshold<s.risk_high_threshold<s.risk_critical_threshold): raise HTTPException(422,'Risk thresholds must be increasing')
    db.commit(); return {k:getattr(s,k) for k in SettingsUpdate.model_fields}

# Serve the local dashboard from the same origin as the API. This avoids a
# separate static server and prevents browser CORS/fetch failures in normal
# local use. It is mounted last so it cannot intercept /api routes.
FRONTEND_DIR = Path(__file__).resolve().parent.parent
if (FRONTEND_DIR / 'index.html').is_file():
    app.mount('/', StaticFiles(directory=FRONTEND_DIR, html=True), name='dashboard')
