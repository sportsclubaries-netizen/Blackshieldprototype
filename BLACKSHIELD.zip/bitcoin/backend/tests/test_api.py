from fastapi.testclient import TestClient

from backend.main import app


client = TestClient(app)


def login_headers():
    response = client.post('/api/auth/login', json={'username': 'owner', 'password': 'demo123'})
    assert response.status_code == 200
    return {'Authorization': f"Bearer {response.json()['access_token']}"}


def test_login_and_dashboard():
    headers = login_headers()
    response = client.get('/api/dashboard/overview', headers=headers)
    assert response.status_code == 200
    assert {'risk_score', 'transactions_monitored', 'active_alerts'} <= response.json().keys()


def test_transaction_and_alert_workflow():
    headers = login_headers()
    response = client.post('/api/transactions', headers=headers, json={
        'transaction_id': 'test-risk-transaction', 'amount': 9.0, 'fee': 0.003,
        'wallet': 'bc1qtestwallet', 'transaction_type': 'withdrawal',
    })
    assert response.status_code in (201, 400)  # repeat runs retain local demo DB
    transactions = client.get('/api/transactions', headers=headers)
    assert transactions.status_code == 200
    alerts = client.get('/api/alerts', headers=headers).json()
    if alerts:
        updated = client.post(f"/api/alerts/{alerts[0]['id']}/acknowledge", headers=headers)
        assert updated.status_code == 200
        assert updated.json()['status'] == 'ACKNOWLEDGED'


def test_upload_validation_and_status():
    headers = login_headers()
    upload = client.post('/api/uploads/transactions', headers=headers, files={
        'file': ('transactions.csv', b'transaction_id,amount\nabc,1.2\n', 'text/csv')
    })
    assert upload.status_code == 200
    assert upload.json()['records'] == 1
    assert client.get('/api/ml/status', headers=headers).status_code == 200


def test_safe_breach_simulation_creates_critical_alert():
    headers = login_headers()
    response = client.post('/api/demo/simulate/potential_breach', headers=headers)
    assert response.status_code == 200
    assert response.json()['simulated'] is True
    assert response.json()['severity'] == 'CRITICAL'
    alerts = client.get('/api/alerts?severity=CRITICAL', headers=headers).json()
    assert any('Simulated' in alert['title'] for alert in alerts)
