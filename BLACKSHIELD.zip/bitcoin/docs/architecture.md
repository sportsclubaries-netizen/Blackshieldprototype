# BLACKSHIELD architecture

BLACKSHIELD is an offline-first prototype. FastAPI receives validated local data and stores it in SQLite. Feature engineering produces transaction amount, fee, and withdrawal indicators for a locally persisted Isolation Forest. A transparent deterministic rule engine separately scores known signals. The risk score is a prototype indicator, not evidence of compromise.

The demo simulator creates only synthetic database records. It never calls a Bitcoin node, modifies a wallet, launches a subprocess, or sends data outside the host. `POST /api/demo/simulate/potential_breach` correlates simulated failed authentication, API deviation, a new withdrawal destination, and a high-value withdrawal into a critical local alert.

## Linux service

Create a dedicated account, install the project in `/opt/blackshield`, create a Python virtual environment there, then copy `systemd/bitcoin-security-agent.service` to `/etc/systemd/system/`. Set database and CORS configuration in `/etc/blackshield/blackshield.env`, run `sudo systemctl daemon-reload`, then `sudo systemctl enable --now bitcoin-security-agent`. Use `systemctl status bitcoin-security-agent` and `journalctl -u bitcoin-security-agent` for local operational review.
