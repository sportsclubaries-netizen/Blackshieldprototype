@echo off
setlocal

where py >nul 2>nul
if errorlevel 1 (
  echo Python 3.12 is required but was not found.
  echo Install it from https://www.python.org/downloads/ and select "Add Python to PATH".
  exit /b 1
)

if not exist "backend\.venv\Scripts\python.exe" (
  py -3.12 -m venv backend\.venv
  if errorlevel 1 exit /b 1
)

call "backend\.venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 exit /b 1
call "backend\.venv\Scripts\python.exe" -m pip install -r backend\requirements.txt
if errorlevel 1 exit /b 1

echo Starting BLACKSHIELD API at http://127.0.0.1:8000/docs
call "backend\.venv\Scripts\python.exe" -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
